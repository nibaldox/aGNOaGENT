export const toolPaths = [
  'openweathermap/open-weather-map/weather-history.js',
  'openweathermap/open-weather-map/call-current-weather-data-for-one-location.js',
  'openweathermap/open-weather-map/forecasted-weather.js'
];